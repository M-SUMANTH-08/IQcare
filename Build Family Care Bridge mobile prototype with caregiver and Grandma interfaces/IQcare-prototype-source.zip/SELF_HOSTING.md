# IQcare prototype — self-hosting notes

IQcare is a frontend-only React/Vite prototype. It uses local React state to demonstrate onboarding, caregiver setup, simulated wearable signals, keypad-phone IVR, Grandma mode, voice/photo actions, shared state, and the 75-second demo. No real smartwatch, telephony, database, or AI service is connected in this prototype.

## Run locally

```bash
pnpm install
pnpm dev
```

For a production build:

```bash
pnpm check
pnpm build
```

The source is under `client/src/`. The main experience is in `client/src/pages/Home.tsx`, the visual system is in `client/src/index.css`, and metadata is in `client/index.html`.

## Replace the demo image

The hosted preview uses a managed IQcare demo image path. For an external host, copy `source-assets/family-care-grandma.jpg` into your public assets folder and change `PHOTO_URL` in `client/src/pages/Home.tsx` from the `/manus-storage/...` path to your local public path, for example `/assets/family-care-grandma.jpg`.

## What is simulated

Wearable readings, unusual-pattern detection, IVR call progress, keypad responses, voice reply audio, AI transcription, and the 75-second demo timeline are simulated for presentation. Before production use, add authenticated backend storage, explicit consent, real telephony, approved wearable APIs, speech-to-text, language support, audit logs, privacy controls, and medical-safety review. The prototype must not diagnose or prescribe medication.
